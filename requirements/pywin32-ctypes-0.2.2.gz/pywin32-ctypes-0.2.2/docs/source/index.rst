.. pywin32-ctypes master documentation file.

===========
win32ctypes
===========

.. include:: ../../README.rst

Reference
=========

.. toctree::

   pywin32

.. include:: ../../CHANGELOG.txt


LICENSE
=======

.. include:: ../../LICENSE.txt


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
