def is_bytes(b):
    return isinstance(b, bytes)


def is_text(s):
    return isinstance(s, str)


def is_integer(i):
    return isinstance(i, int)
